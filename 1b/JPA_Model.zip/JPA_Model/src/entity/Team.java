/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Bernard Kapinda
 */
@Entity
@Table(name = "team")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Team.findAll", query = "SELECT t FROM Team t")
    , @NamedQuery(name = "Team.findById", query = "SELECT t FROM Team t WHERE t.id = :id")
    , @NamedQuery(name = "Team.findByCountry", query = "SELECT t FROM Team t WHERE t.country = :country")
    , @NamedQuery(name = "Team.findByAlternateName", query = "SELECT t FROM Team t WHERE t.alternateName = :alternateName")
    , @NamedQuery(name = "Team.findByFifaCode", query = "SELECT t FROM Team t WHERE t.fifaCode = :fifaCode")
    , @NamedQuery(name = "Team.findByGroupId", query = "SELECT t FROM Team t WHERE t.groupId = :groupId")
    , @NamedQuery(name = "Team.findByGroupLetter", query = "SELECT t FROM Team t WHERE t.groupLetter = :groupLetter")})
public class Team implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "country")
    private String country;
    @Column(name = "alternate_name")
    private String alternateName;
    @Basic(optional = false)
    @Column(name = "fifa_code")
    private String fifaCode;
    @Basic(optional = false)
    @Column(name = "group_id")
    private int groupId;
    @Basic(optional = false)
    @Column(name = "group_letter")
    private String groupLetter;

    public Team() {
    }

    public Team(Integer id) {
        this.id = id;
    }

    public Team(Integer id, String country, String fifaCode, int groupId, String groupLetter) {
        this.id = id;
        this.country = country;
        this.fifaCode = fifaCode;
        this.groupId = groupId;
        this.groupLetter = groupLetter;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAlternateName() {
        return alternateName;
    }

    public void setAlternateName(String alternateName) {
        this.alternateName = alternateName;
    }

    public String getFifaCode() {
        return fifaCode;
    }

    public void setFifaCode(String fifaCode) {
        this.fifaCode = fifaCode;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getGroupLetter() {
        return groupLetter;
    }

    public void setGroupLetter(String groupLetter) {
        this.groupLetter = groupLetter;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Team)) {
            return false;
        }
        Team other = (Team) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Team[ id=" + id + " ]";
    }
    
}
