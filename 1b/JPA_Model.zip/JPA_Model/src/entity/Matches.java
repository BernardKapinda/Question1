/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Bernard Kapinda
 */
@Entity
@Table(name = "matches")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Matches.findAll", query = "SELECT m FROM Matches m")
    , @NamedQuery(name = "Matches.findByVenue", query = "SELECT m FROM Matches m WHERE m.venue = :venue")
    , @NamedQuery(name = "Matches.findByLocation", query = "SELECT m FROM Matches m WHERE m.location = :location")
    , @NamedQuery(name = "Matches.findByStatus", query = "SELECT m FROM Matches m WHERE m.status = :status")
    , @NamedQuery(name = "Matches.findByTime", query = "SELECT m FROM Matches m WHERE m.time = :time")
    , @NamedQuery(name = "Matches.findByFifaId", query = "SELECT m FROM Matches m WHERE m.fifaId = :fifaId")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsattemptsOnGoal", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsattemptsOnGoal = :homeTeamStatisticsattemptsOnGoal")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsonTarget", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsonTarget = :homeTeamStatisticsonTarget")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsoffTarget", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsoffTarget = :homeTeamStatisticsoffTarget")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsblocked", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsblocked = :homeTeamStatisticsblocked")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticswoodwork", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticswoodwork = :homeTeamStatisticswoodwork")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticscorners", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticscorners = :homeTeamStatisticscorners")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsoffsides", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsoffsides = :homeTeamStatisticsoffsides")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsballPossession", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsballPossession = :homeTeamStatisticsballPossession")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticspassAccuracy", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticspassAccuracy = :homeTeamStatisticspassAccuracy")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsnumPasses", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsnumPasses = :homeTeamStatisticsnumPasses")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticspassesCompleted", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticspassesCompleted = :homeTeamStatisticspassesCompleted")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsdistanceCovered", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsdistanceCovered = :homeTeamStatisticsdistanceCovered")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsballsRecovered", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsballsRecovered = :homeTeamStatisticsballsRecovered")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticstackles", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticstackles = :homeTeamStatisticstackles")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsclearances", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsclearances = :homeTeamStatisticsclearances")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsyellowCards", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsyellowCards = :homeTeamStatisticsyellowCards")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsredCards", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsredCards = :homeTeamStatisticsredCards")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticsfoulsCommitted", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticsfoulsCommitted = :homeTeamStatisticsfoulsCommitted")
    , @NamedQuery(name = "Matches.findByHomeTeamStatisticscountry", query = "SELECT m FROM Matches m WHERE m.homeTeamStatisticscountry = :homeTeamStatisticscountry")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsattemptsOnGoal", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsattemptsOnGoal = :awayTeamStatisticsattemptsOnGoal")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsonTarget", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsonTarget = :awayTeamStatisticsonTarget")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsoffTarget", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsoffTarget = :awayTeamStatisticsoffTarget")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsblocked", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsblocked = :awayTeamStatisticsblocked")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticswoodwork", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticswoodwork = :awayTeamStatisticswoodwork")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticscorners", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticscorners = :awayTeamStatisticscorners")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsoffsides", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsoffsides = :awayTeamStatisticsoffsides")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsballPossession", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsballPossession = :awayTeamStatisticsballPossession")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticspassAccuracy", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticspassAccuracy = :awayTeamStatisticspassAccuracy")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsnumPasses", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsnumPasses = :awayTeamStatisticsnumPasses")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticspassesCompleted", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticspassesCompleted = :awayTeamStatisticspassesCompleted")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsdistanceCovered", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsdistanceCovered = :awayTeamStatisticsdistanceCovered")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsballsRecovered", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsballsRecovered = :awayTeamStatisticsballsRecovered")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticstackles", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticstackles = :awayTeamStatisticstackles")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsclearances", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsclearances = :awayTeamStatisticsclearances")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsyellowCards", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsyellowCards = :awayTeamStatisticsyellowCards")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsredCards", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsredCards = :awayTeamStatisticsredCards")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticsfoulsCommitted", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticsfoulsCommitted = :awayTeamStatisticsfoulsCommitted")
    , @NamedQuery(name = "Matches.findByAwayTeamStatisticscountry", query = "SELECT m FROM Matches m WHERE m.awayTeamStatisticscountry = :awayTeamStatisticscountry")
    , @NamedQuery(name = "Matches.findByDatetime", query = "SELECT m FROM Matches m WHERE m.datetime = :datetime")
    , @NamedQuery(name = "Matches.findByLastEventUpdateAt", query = "SELECT m FROM Matches m WHERE m.lastEventUpdateAt = :lastEventUpdateAt")
    , @NamedQuery(name = "Matches.findByLastScoreUpdateAt", query = "SELECT m FROM Matches m WHERE m.lastScoreUpdateAt = :lastScoreUpdateAt")
    , @NamedQuery(name = "Matches.findByHomeTeamcountry", query = "SELECT m FROM Matches m WHERE m.homeTeamcountry = :homeTeamcountry")
    , @NamedQuery(name = "Matches.findByHomeTeamcode", query = "SELECT m FROM Matches m WHERE m.homeTeamcode = :homeTeamcode")
    , @NamedQuery(name = "Matches.findByHomeTeamgoals", query = "SELECT m FROM Matches m WHERE m.homeTeamgoals = :homeTeamgoals")
    , @NamedQuery(name = "Matches.findByAwayTeamcountry", query = "SELECT m FROM Matches m WHERE m.awayTeamcountry = :awayTeamcountry")
    , @NamedQuery(name = "Matches.findByAwayTeamcode", query = "SELECT m FROM Matches m WHERE m.awayTeamcode = :awayTeamcode")
    , @NamedQuery(name = "Matches.findByAwayTeamgoals", query = "SELECT m FROM Matches m WHERE m.awayTeamgoals = :awayTeamgoals")
    , @NamedQuery(name = "Matches.findByWinner", query = "SELECT m FROM Matches m WHERE m.winner = :winner")
    , @NamedQuery(name = "Matches.findByWinnerCode", query = "SELECT m FROM Matches m WHERE m.winnerCode = :winnerCode")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents0id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents0id = :homeTeamEvents0id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents0typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents0typeOfEvent = :homeTeamEvents0typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents0player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents0player = :homeTeamEvents0player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents0time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents0time = :homeTeamEvents0time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents1id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents1id = :homeTeamEvents1id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents1typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents1typeOfEvent = :homeTeamEvents1typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents1player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents1player = :homeTeamEvents1player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents1time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents1time = :homeTeamEvents1time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents2id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents2id = :homeTeamEvents2id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents2typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents2typeOfEvent = :homeTeamEvents2typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents2player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents2player = :homeTeamEvents2player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents2time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents2time = :homeTeamEvents2time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents3id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents3id = :homeTeamEvents3id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents3typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents3typeOfEvent = :homeTeamEvents3typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents3player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents3player = :homeTeamEvents3player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents3time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents3time = :homeTeamEvents3time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents4id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents4id = :homeTeamEvents4id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents4typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents4typeOfEvent = :homeTeamEvents4typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents4player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents4player = :homeTeamEvents4player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents4time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents4time = :homeTeamEvents4time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents5id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents5id = :homeTeamEvents5id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents5typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents5typeOfEvent = :homeTeamEvents5typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents5player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents5player = :homeTeamEvents5player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents5time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents5time = :homeTeamEvents5time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents6id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents6id = :homeTeamEvents6id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents6typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents6typeOfEvent = :homeTeamEvents6typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents6player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents6player = :homeTeamEvents6player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents6time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents6time = :homeTeamEvents6time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents7id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents7id = :homeTeamEvents7id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents7typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents7typeOfEvent = :homeTeamEvents7typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents7player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents7player = :homeTeamEvents7player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents7time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents7time = :homeTeamEvents7time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents8id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents8id = :homeTeamEvents8id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents8typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents8typeOfEvent = :homeTeamEvents8typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents8player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents8player = :homeTeamEvents8player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents8time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents8time = :homeTeamEvents8time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents9id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents9id = :homeTeamEvents9id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents9typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents9typeOfEvent = :homeTeamEvents9typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents9player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents9player = :homeTeamEvents9player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents9time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents9time = :homeTeamEvents9time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents10id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents10id = :homeTeamEvents10id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents10typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents10typeOfEvent = :homeTeamEvents10typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents10player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents10player = :homeTeamEvents10player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents10time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents10time = :homeTeamEvents10time")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents11id", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents11id = :homeTeamEvents11id")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents11typeOfEvent", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents11typeOfEvent = :homeTeamEvents11typeOfEvent")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents11player", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents11player = :homeTeamEvents11player")
    , @NamedQuery(name = "Matches.findByHomeTeamEvents11time", query = "SELECT m FROM Matches m WHERE m.homeTeamEvents11time = :homeTeamEvents11time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents0id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents0id = :awayTeamEvents0id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents0typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents0typeOfEvent = :awayTeamEvents0typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents0player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents0player = :awayTeamEvents0player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents0time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents0time = :awayTeamEvents0time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents1id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents1id = :awayTeamEvents1id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents1typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents1typeOfEvent = :awayTeamEvents1typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents1player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents1player = :awayTeamEvents1player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents1time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents1time = :awayTeamEvents1time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents2id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents2id = :awayTeamEvents2id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents2typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents2typeOfEvent = :awayTeamEvents2typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents2player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents2player = :awayTeamEvents2player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents2time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents2time = :awayTeamEvents2time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents3id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents3id = :awayTeamEvents3id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents3typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents3typeOfEvent = :awayTeamEvents3typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents3player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents3player = :awayTeamEvents3player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents3time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents3time = :awayTeamEvents3time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents4id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents4id = :awayTeamEvents4id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents4typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents4typeOfEvent = :awayTeamEvents4typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents4player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents4player = :awayTeamEvents4player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents4time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents4time = :awayTeamEvents4time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents5id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents5id = :awayTeamEvents5id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents5typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents5typeOfEvent = :awayTeamEvents5typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents5player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents5player = :awayTeamEvents5player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents5time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents5time = :awayTeamEvents5time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents6id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents6id = :awayTeamEvents6id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents6typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents6typeOfEvent = :awayTeamEvents6typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents6player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents6player = :awayTeamEvents6player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents6time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents6time = :awayTeamEvents6time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents7id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents7id = :awayTeamEvents7id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents7typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents7typeOfEvent = :awayTeamEvents7typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents7player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents7player = :awayTeamEvents7player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents7time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents7time = :awayTeamEvents7time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents8id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents8id = :awayTeamEvents8id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents8typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents8typeOfEvent = :awayTeamEvents8typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents8player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents8player = :awayTeamEvents8player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents8time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents8time = :awayTeamEvents8time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents9id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents9id = :awayTeamEvents9id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents9typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents9typeOfEvent = :awayTeamEvents9typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents9player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents9player = :awayTeamEvents9player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents9time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents9time = :awayTeamEvents9time")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents10id", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents10id = :awayTeamEvents10id")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents10typeOfEvent", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents10typeOfEvent = :awayTeamEvents10typeOfEvent")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents10player", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents10player = :awayTeamEvents10player")
    , @NamedQuery(name = "Matches.findByAwayTeamEvents10time", query = "SELECT m FROM Matches m WHERE m.awayTeamEvents10time = :awayTeamEvents10time")
    , @NamedQuery(name = "Matches.findByHomeTeamStatistics", query = "SELECT m FROM Matches m WHERE m.homeTeamStatistics = :homeTeamStatistics")
    , @NamedQuery(name = "Matches.findByAwayTeamStatistics", query = "SELECT m FROM Matches m WHERE m.awayTeamStatistics = :awayTeamStatistics")
    , @NamedQuery(name = "Matches.findByHomeTeamteamTbd", query = "SELECT m FROM Matches m WHERE m.homeTeamteamTbd = :homeTeamteamTbd")
    , @NamedQuery(name = "Matches.findByAwayTeamteamTbd", query = "SELECT m FROM Matches m WHERE m.awayTeamteamTbd = :awayTeamteamTbd")})
public class Matches implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "venue")
    private String venue;
    @Basic(optional = false)
    @Column(name = "location")
    private String location;
    @Basic(optional = false)
    @Column(name = "status")
    private String status;
    @Column(name = "time")
    private String time;
    @Basic(optional = false)
    @Column(name = "fifa_id")
    private int fifaId;
    @Column(name = "home_team_statisticsattempts_on_goal")
    private Integer homeTeamStatisticsattemptsOnGoal;
    @Column(name = "home_team_statisticson_target")
    private Integer homeTeamStatisticsonTarget;
    @Column(name = "home_team_statisticsoff_target")
    private Integer homeTeamStatisticsoffTarget;
    @Column(name = "home_team_statisticsblocked")
    private Integer homeTeamStatisticsblocked;
    @Column(name = "home_team_statisticswoodwork")
    private Integer homeTeamStatisticswoodwork;
    @Column(name = "home_team_statisticscorners")
    private Integer homeTeamStatisticscorners;
    @Column(name = "home_team_statisticsoffsides")
    private Integer homeTeamStatisticsoffsides;
    @Column(name = "home_team_statisticsball_possession")
    private Integer homeTeamStatisticsballPossession;
    @Column(name = "home_team_statisticspass_accuracy")
    private Integer homeTeamStatisticspassAccuracy;
    @Column(name = "home_team_statisticsnum_passes")
    private Integer homeTeamStatisticsnumPasses;
    @Column(name = "home_team_statisticspasses_completed")
    private Integer homeTeamStatisticspassesCompleted;
    @Column(name = "home_team_statisticsdistance_covered")
    private Integer homeTeamStatisticsdistanceCovered;
    @Column(name = "home_team_statisticsballs_recovered")
    private Integer homeTeamStatisticsballsRecovered;
    @Column(name = "home_team_statisticstackles")
    private Integer homeTeamStatisticstackles;
    @Column(name = "home_team_statisticsclearances")
    private Integer homeTeamStatisticsclearances;
    @Column(name = "home_team_statisticsyellow_cards")
    private Integer homeTeamStatisticsyellowCards;
    @Column(name = "home_team_statisticsred_cards")
    private Boolean homeTeamStatisticsredCards;
    @Column(name = "home_team_statisticsfouls_committed")
    private Integer homeTeamStatisticsfoulsCommitted;
    @Column(name = "home_team_statisticscountry")
    private String homeTeamStatisticscountry;
    @Column(name = "away_team_statisticsattempts_on_goal")
    private Integer awayTeamStatisticsattemptsOnGoal;
    @Column(name = "away_team_statisticson_target")
    private Integer awayTeamStatisticsonTarget;
    @Column(name = "away_team_statisticsoff_target")
    private Integer awayTeamStatisticsoffTarget;
    @Column(name = "away_team_statisticsblocked")
    private Integer awayTeamStatisticsblocked;
    @Column(name = "away_team_statisticswoodwork")
    private Integer awayTeamStatisticswoodwork;
    @Column(name = "away_team_statisticscorners")
    private Integer awayTeamStatisticscorners;
    @Column(name = "away_team_statisticsoffsides")
    private Integer awayTeamStatisticsoffsides;
    @Column(name = "away_team_statisticsball_possession")
    private Integer awayTeamStatisticsballPossession;
    @Column(name = "away_team_statisticspass_accuracy")
    private Integer awayTeamStatisticspassAccuracy;
    @Column(name = "away_team_statisticsnum_passes")
    private Integer awayTeamStatisticsnumPasses;
    @Column(name = "away_team_statisticspasses_completed")
    private Integer awayTeamStatisticspassesCompleted;
    @Column(name = "away_team_statisticsdistance_covered")
    private Integer awayTeamStatisticsdistanceCovered;
    @Column(name = "away_team_statisticsballs_recovered")
    private Integer awayTeamStatisticsballsRecovered;
    @Column(name = "away_team_statisticstackles")
    private Integer awayTeamStatisticstackles;
    @Column(name = "away_team_statisticsclearances")
    private Integer awayTeamStatisticsclearances;
    @Column(name = "away_team_statisticsyellow_cards")
    private Integer awayTeamStatisticsyellowCards;
    @Column(name = "away_team_statisticsred_cards")
    private Boolean awayTeamStatisticsredCards;
    @Column(name = "away_team_statisticsfouls_committed")
    private Integer awayTeamStatisticsfoulsCommitted;
    @Column(name = "away_team_statisticscountry")
    private String awayTeamStatisticscountry;
    @Basic(optional = false)
    @Column(name = "datetime")
    private String datetime;
    @Column(name = "last_event_update_at")
    private String lastEventUpdateAt;
    @Column(name = "last_score_update_at")
    private String lastScoreUpdateAt;
    @Basic(optional = false)
    @Column(name = "home_teamcountry")
    private String homeTeamcountry;
    @Basic(optional = false)
    @Column(name = "home_teamcode")
    private String homeTeamcode;
    @Column(name = "home_teamgoals")
    private Integer homeTeamgoals;
    @Basic(optional = false)
    @Column(name = "away_teamcountry")
    private String awayTeamcountry;
    @Basic(optional = false)
    @Column(name = "away_teamcode")
    private String awayTeamcode;
    @Column(name = "away_teamgoals")
    private Integer awayTeamgoals;
    @Column(name = "winner")
    private String winner;
    @Column(name = "winner_code")
    private String winnerCode;
    @Column(name = "home_team_events0id")
    private Integer homeTeamEvents0id;
    @Column(name = "home_team_events0type_of_event")
    private String homeTeamEvents0typeOfEvent;
    @Column(name = "home_team_events0player")
    private String homeTeamEvents0player;
    @Column(name = "home_team_events0time")
    private String homeTeamEvents0time;
    @Column(name = "home_team_events1id")
    private Integer homeTeamEvents1id;
    @Column(name = "home_team_events1type_of_event")
    private String homeTeamEvents1typeOfEvent;
    @Column(name = "home_team_events1player")
    private String homeTeamEvents1player;
    @Column(name = "home_team_events1time")
    private String homeTeamEvents1time;
    @Column(name = "home_team_events2id")
    private Integer homeTeamEvents2id;
    @Column(name = "home_team_events2type_of_event")
    private String homeTeamEvents2typeOfEvent;
    @Column(name = "home_team_events2player")
    private String homeTeamEvents2player;
    @Column(name = "home_team_events2time")
    private String homeTeamEvents2time;
    @Column(name = "home_team_events3id")
    private Integer homeTeamEvents3id;
    @Column(name = "home_team_events3type_of_event")
    private String homeTeamEvents3typeOfEvent;
    @Column(name = "home_team_events3player")
    private String homeTeamEvents3player;
    @Column(name = "home_team_events3time")
    @Temporal(TemporalType.DATE)
    private Date homeTeamEvents3time;
    @Column(name = "home_team_events4id")
    private Integer homeTeamEvents4id;
    @Column(name = "home_team_events4type_of_event")
    private String homeTeamEvents4typeOfEvent;
    @Column(name = "home_team_events4player")
    private String homeTeamEvents4player;
    @Column(name = "home_team_events4time")
    @Temporal(TemporalType.DATE)
    private Date homeTeamEvents4time;
    @Column(name = "home_team_events5id")
    private Integer homeTeamEvents5id;
    @Column(name = "home_team_events5type_of_event")
    private String homeTeamEvents5typeOfEvent;
    @Column(name = "home_team_events5player")
    private String homeTeamEvents5player;
    @Column(name = "home_team_events5time")
    @Temporal(TemporalType.DATE)
    private Date homeTeamEvents5time;
    @Column(name = "home_team_events6id")
    private Integer homeTeamEvents6id;
    @Column(name = "home_team_events6type_of_event")
    private String homeTeamEvents6typeOfEvent;
    @Column(name = "home_team_events6player")
    private String homeTeamEvents6player;
    @Column(name = "home_team_events6time")
    private String homeTeamEvents6time;
    @Column(name = "home_team_events7id")
    private Integer homeTeamEvents7id;
    @Column(name = "home_team_events7type_of_event")
    private String homeTeamEvents7typeOfEvent;
    @Column(name = "home_team_events7player")
    private String homeTeamEvents7player;
    @Column(name = "home_team_events7time")
    private String homeTeamEvents7time;
    @Column(name = "home_team_events8id")
    private Integer homeTeamEvents8id;
    @Column(name = "home_team_events8type_of_event")
    private String homeTeamEvents8typeOfEvent;
    @Column(name = "home_team_events8player")
    private String homeTeamEvents8player;
    @Column(name = "home_team_events8time")
    private String homeTeamEvents8time;
    @Column(name = "home_team_events9id")
    private Integer homeTeamEvents9id;
    @Column(name = "home_team_events9type_of_event")
    private String homeTeamEvents9typeOfEvent;
    @Column(name = "home_team_events9player")
    private String homeTeamEvents9player;
    @Column(name = "home_team_events9time")
    @Temporal(TemporalType.DATE)
    private Date homeTeamEvents9time;
    @Column(name = "home_team_events10id")
    private Integer homeTeamEvents10id;
    @Column(name = "home_team_events10type_of_event")
    private String homeTeamEvents10typeOfEvent;
    @Column(name = "home_team_events10player")
    private String homeTeamEvents10player;
    @Column(name = "home_team_events10time")
    private String homeTeamEvents10time;
    @Column(name = "home_team_events11id")
    private Integer homeTeamEvents11id;
    @Column(name = "home_team_events11type_of_event")
    private String homeTeamEvents11typeOfEvent;
    @Column(name = "home_team_events11player")
    private String homeTeamEvents11player;
    @Column(name = "home_team_events11time")
    private String homeTeamEvents11time;
    @Column(name = "away_team_events0id")
    private Integer awayTeamEvents0id;
    @Column(name = "away_team_events0type_of_event")
    private String awayTeamEvents0typeOfEvent;
    @Column(name = "away_team_events0player")
    private String awayTeamEvents0player;
    @Column(name = "away_team_events0time")
    private String awayTeamEvents0time;
    @Column(name = "away_team_events1id")
    private Integer awayTeamEvents1id;
    @Column(name = "away_team_events1type_of_event")
    private String awayTeamEvents1typeOfEvent;
    @Column(name = "away_team_events1player")
    private String awayTeamEvents1player;
    @Column(name = "away_team_events1time")
    private String awayTeamEvents1time;
    @Column(name = "away_team_events2id")
    private Integer awayTeamEvents2id;
    @Column(name = "away_team_events2type_of_event")
    private String awayTeamEvents2typeOfEvent;
    @Column(name = "away_team_events2player")
    private String awayTeamEvents2player;
    @Column(name = "away_team_events2time")
    private String awayTeamEvents2time;
    @Column(name = "away_team_events3id")
    private Integer awayTeamEvents3id;
    @Column(name = "away_team_events3type_of_event")
    private String awayTeamEvents3typeOfEvent;
    @Column(name = "away_team_events3player")
    private String awayTeamEvents3player;
    @Column(name = "away_team_events3time")
    @Temporal(TemporalType.DATE)
    private Date awayTeamEvents3time;
    @Column(name = "away_team_events4id")
    private Integer awayTeamEvents4id;
    @Column(name = "away_team_events4type_of_event")
    private String awayTeamEvents4typeOfEvent;
    @Column(name = "away_team_events4player")
    private String awayTeamEvents4player;
    @Column(name = "away_team_events4time")
    @Temporal(TemporalType.DATE)
    private Date awayTeamEvents4time;
    @Column(name = "away_team_events5id")
    private Integer awayTeamEvents5id;
    @Column(name = "away_team_events5type_of_event")
    private String awayTeamEvents5typeOfEvent;
    @Column(name = "away_team_events5player")
    private String awayTeamEvents5player;
    @Column(name = "away_team_events5time")
    @Temporal(TemporalType.DATE)
    private Date awayTeamEvents5time;
    @Column(name = "away_team_events6id")
    private Integer awayTeamEvents6id;
    @Column(name = "away_team_events6type_of_event")
    private String awayTeamEvents6typeOfEvent;
    @Column(name = "away_team_events6player")
    private String awayTeamEvents6player;
    @Column(name = "away_team_events6time")
    private String awayTeamEvents6time;
    @Column(name = "away_team_events7id")
    private Integer awayTeamEvents7id;
    @Column(name = "away_team_events7type_of_event")
    private String awayTeamEvents7typeOfEvent;
    @Column(name = "away_team_events7player")
    private String awayTeamEvents7player;
    @Column(name = "away_team_events7time")
    private String awayTeamEvents7time;
    @Column(name = "away_team_events8id")
    private Integer awayTeamEvents8id;
    @Column(name = "away_team_events8type_of_event")
    private String awayTeamEvents8typeOfEvent;
    @Column(name = "away_team_events8player")
    private String awayTeamEvents8player;
    @Column(name = "away_team_events8time")
    private String awayTeamEvents8time;
    @Column(name = "away_team_events9id")
    private Integer awayTeamEvents9id;
    @Column(name = "away_team_events9type_of_event")
    private String awayTeamEvents9typeOfEvent;
    @Column(name = "away_team_events9player")
    private String awayTeamEvents9player;
    @Column(name = "away_team_events9time")
    @Temporal(TemporalType.DATE)
    private Date awayTeamEvents9time;
    @Column(name = "away_team_events10id")
    private Integer awayTeamEvents10id;
    @Column(name = "away_team_events10type_of_event")
    private String awayTeamEvents10typeOfEvent;
    @Column(name = "away_team_events10player")
    private String awayTeamEvents10player;
    @Column(name = "away_team_events10time")
    private String awayTeamEvents10time;
    @Column(name = "home_team_statistics")
    private String homeTeamStatistics;
    @Column(name = "away_team_statistics")
    private String awayTeamStatistics;
    @Column(name = "home_teamteam_tbd")
    private String homeTeamteamTbd;
    @Column(name = "away_teamteam_tbd")
    private String awayTeamteamTbd;

    public Matches() {
    }

    public Matches(String venue) {
        this.venue = venue;
    }

    public Matches(String venue, String location, String status, int fifaId, String datetime, String homeTeamcountry, String homeTeamcode, String awayTeamcountry, String awayTeamcode) {
        this.venue = venue;
        this.location = location;
        this.status = status;
        this.fifaId = fifaId;
        this.datetime = datetime;
        this.homeTeamcountry = homeTeamcountry;
        this.homeTeamcode = homeTeamcode;
        this.awayTeamcountry = awayTeamcountry;
        this.awayTeamcode = awayTeamcode;
    }

    public String getVenue() {
        return venue;
    }

    public void setVenue(String venue) {
        this.venue = venue;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getFifaId() {
        return fifaId;
    }

    public void setFifaId(int fifaId) {
        this.fifaId = fifaId;
    }

    public Integer getHomeTeamStatisticsattemptsOnGoal() {
        return homeTeamStatisticsattemptsOnGoal;
    }

    public void setHomeTeamStatisticsattemptsOnGoal(Integer homeTeamStatisticsattemptsOnGoal) {
        this.homeTeamStatisticsattemptsOnGoal = homeTeamStatisticsattemptsOnGoal;
    }

    public Integer getHomeTeamStatisticsonTarget() {
        return homeTeamStatisticsonTarget;
    }

    public void setHomeTeamStatisticsonTarget(Integer homeTeamStatisticsonTarget) {
        this.homeTeamStatisticsonTarget = homeTeamStatisticsonTarget;
    }

    public Integer getHomeTeamStatisticsoffTarget() {
        return homeTeamStatisticsoffTarget;
    }

    public void setHomeTeamStatisticsoffTarget(Integer homeTeamStatisticsoffTarget) {
        this.homeTeamStatisticsoffTarget = homeTeamStatisticsoffTarget;
    }

    public Integer getHomeTeamStatisticsblocked() {
        return homeTeamStatisticsblocked;
    }

    public void setHomeTeamStatisticsblocked(Integer homeTeamStatisticsblocked) {
        this.homeTeamStatisticsblocked = homeTeamStatisticsblocked;
    }

    public Integer getHomeTeamStatisticswoodwork() {
        return homeTeamStatisticswoodwork;
    }

    public void setHomeTeamStatisticswoodwork(Integer homeTeamStatisticswoodwork) {
        this.homeTeamStatisticswoodwork = homeTeamStatisticswoodwork;
    }

    public Integer getHomeTeamStatisticscorners() {
        return homeTeamStatisticscorners;
    }

    public void setHomeTeamStatisticscorners(Integer homeTeamStatisticscorners) {
        this.homeTeamStatisticscorners = homeTeamStatisticscorners;
    }

    public Integer getHomeTeamStatisticsoffsides() {
        return homeTeamStatisticsoffsides;
    }

    public void setHomeTeamStatisticsoffsides(Integer homeTeamStatisticsoffsides) {
        this.homeTeamStatisticsoffsides = homeTeamStatisticsoffsides;
    }

    public Integer getHomeTeamStatisticsballPossession() {
        return homeTeamStatisticsballPossession;
    }

    public void setHomeTeamStatisticsballPossession(Integer homeTeamStatisticsballPossession) {
        this.homeTeamStatisticsballPossession = homeTeamStatisticsballPossession;
    }

    public Integer getHomeTeamStatisticspassAccuracy() {
        return homeTeamStatisticspassAccuracy;
    }

    public void setHomeTeamStatisticspassAccuracy(Integer homeTeamStatisticspassAccuracy) {
        this.homeTeamStatisticspassAccuracy = homeTeamStatisticspassAccuracy;
    }

    public Integer getHomeTeamStatisticsnumPasses() {
        return homeTeamStatisticsnumPasses;
    }

    public void setHomeTeamStatisticsnumPasses(Integer homeTeamStatisticsnumPasses) {
        this.homeTeamStatisticsnumPasses = homeTeamStatisticsnumPasses;
    }

    public Integer getHomeTeamStatisticspassesCompleted() {
        return homeTeamStatisticspassesCompleted;
    }

    public void setHomeTeamStatisticspassesCompleted(Integer homeTeamStatisticspassesCompleted) {
        this.homeTeamStatisticspassesCompleted = homeTeamStatisticspassesCompleted;
    }

    public Integer getHomeTeamStatisticsdistanceCovered() {
        return homeTeamStatisticsdistanceCovered;
    }

    public void setHomeTeamStatisticsdistanceCovered(Integer homeTeamStatisticsdistanceCovered) {
        this.homeTeamStatisticsdistanceCovered = homeTeamStatisticsdistanceCovered;
    }

    public Integer getHomeTeamStatisticsballsRecovered() {
        return homeTeamStatisticsballsRecovered;
    }

    public void setHomeTeamStatisticsballsRecovered(Integer homeTeamStatisticsballsRecovered) {
        this.homeTeamStatisticsballsRecovered = homeTeamStatisticsballsRecovered;
    }

    public Integer getHomeTeamStatisticstackles() {
        return homeTeamStatisticstackles;
    }

    public void setHomeTeamStatisticstackles(Integer homeTeamStatisticstackles) {
        this.homeTeamStatisticstackles = homeTeamStatisticstackles;
    }

    public Integer getHomeTeamStatisticsclearances() {
        return homeTeamStatisticsclearances;
    }

    public void setHomeTeamStatisticsclearances(Integer homeTeamStatisticsclearances) {
        this.homeTeamStatisticsclearances = homeTeamStatisticsclearances;
    }

    public Integer getHomeTeamStatisticsyellowCards() {
        return homeTeamStatisticsyellowCards;
    }

    public void setHomeTeamStatisticsyellowCards(Integer homeTeamStatisticsyellowCards) {
        this.homeTeamStatisticsyellowCards = homeTeamStatisticsyellowCards;
    }

    public Boolean getHomeTeamStatisticsredCards() {
        return homeTeamStatisticsredCards;
    }

    public void setHomeTeamStatisticsredCards(Boolean homeTeamStatisticsredCards) {
        this.homeTeamStatisticsredCards = homeTeamStatisticsredCards;
    }

    public Integer getHomeTeamStatisticsfoulsCommitted() {
        return homeTeamStatisticsfoulsCommitted;
    }

    public void setHomeTeamStatisticsfoulsCommitted(Integer homeTeamStatisticsfoulsCommitted) {
        this.homeTeamStatisticsfoulsCommitted = homeTeamStatisticsfoulsCommitted;
    }

    public String getHomeTeamStatisticscountry() {
        return homeTeamStatisticscountry;
    }

    public void setHomeTeamStatisticscountry(String homeTeamStatisticscountry) {
        this.homeTeamStatisticscountry = homeTeamStatisticscountry;
    }

    public Integer getAwayTeamStatisticsattemptsOnGoal() {
        return awayTeamStatisticsattemptsOnGoal;
    }

    public void setAwayTeamStatisticsattemptsOnGoal(Integer awayTeamStatisticsattemptsOnGoal) {
        this.awayTeamStatisticsattemptsOnGoal = awayTeamStatisticsattemptsOnGoal;
    }

    public Integer getAwayTeamStatisticsonTarget() {
        return awayTeamStatisticsonTarget;
    }

    public void setAwayTeamStatisticsonTarget(Integer awayTeamStatisticsonTarget) {
        this.awayTeamStatisticsonTarget = awayTeamStatisticsonTarget;
    }

    public Integer getAwayTeamStatisticsoffTarget() {
        return awayTeamStatisticsoffTarget;
    }

    public void setAwayTeamStatisticsoffTarget(Integer awayTeamStatisticsoffTarget) {
        this.awayTeamStatisticsoffTarget = awayTeamStatisticsoffTarget;
    }

    public Integer getAwayTeamStatisticsblocked() {
        return awayTeamStatisticsblocked;
    }

    public void setAwayTeamStatisticsblocked(Integer awayTeamStatisticsblocked) {
        this.awayTeamStatisticsblocked = awayTeamStatisticsblocked;
    }

    public Integer getAwayTeamStatisticswoodwork() {
        return awayTeamStatisticswoodwork;
    }

    public void setAwayTeamStatisticswoodwork(Integer awayTeamStatisticswoodwork) {
        this.awayTeamStatisticswoodwork = awayTeamStatisticswoodwork;
    }

    public Integer getAwayTeamStatisticscorners() {
        return awayTeamStatisticscorners;
    }

    public void setAwayTeamStatisticscorners(Integer awayTeamStatisticscorners) {
        this.awayTeamStatisticscorners = awayTeamStatisticscorners;
    }

    public Integer getAwayTeamStatisticsoffsides() {
        return awayTeamStatisticsoffsides;
    }

    public void setAwayTeamStatisticsoffsides(Integer awayTeamStatisticsoffsides) {
        this.awayTeamStatisticsoffsides = awayTeamStatisticsoffsides;
    }

    public Integer getAwayTeamStatisticsballPossession() {
        return awayTeamStatisticsballPossession;
    }

    public void setAwayTeamStatisticsballPossession(Integer awayTeamStatisticsballPossession) {
        this.awayTeamStatisticsballPossession = awayTeamStatisticsballPossession;
    }

    public Integer getAwayTeamStatisticspassAccuracy() {
        return awayTeamStatisticspassAccuracy;
    }

    public void setAwayTeamStatisticspassAccuracy(Integer awayTeamStatisticspassAccuracy) {
        this.awayTeamStatisticspassAccuracy = awayTeamStatisticspassAccuracy;
    }

    public Integer getAwayTeamStatisticsnumPasses() {
        return awayTeamStatisticsnumPasses;
    }

    public void setAwayTeamStatisticsnumPasses(Integer awayTeamStatisticsnumPasses) {
        this.awayTeamStatisticsnumPasses = awayTeamStatisticsnumPasses;
    }

    public Integer getAwayTeamStatisticspassesCompleted() {
        return awayTeamStatisticspassesCompleted;
    }

    public void setAwayTeamStatisticspassesCompleted(Integer awayTeamStatisticspassesCompleted) {
        this.awayTeamStatisticspassesCompleted = awayTeamStatisticspassesCompleted;
    }

    public Integer getAwayTeamStatisticsdistanceCovered() {
        return awayTeamStatisticsdistanceCovered;
    }

    public void setAwayTeamStatisticsdistanceCovered(Integer awayTeamStatisticsdistanceCovered) {
        this.awayTeamStatisticsdistanceCovered = awayTeamStatisticsdistanceCovered;
    }

    public Integer getAwayTeamStatisticsballsRecovered() {
        return awayTeamStatisticsballsRecovered;
    }

    public void setAwayTeamStatisticsballsRecovered(Integer awayTeamStatisticsballsRecovered) {
        this.awayTeamStatisticsballsRecovered = awayTeamStatisticsballsRecovered;
    }

    public Integer getAwayTeamStatisticstackles() {
        return awayTeamStatisticstackles;
    }

    public void setAwayTeamStatisticstackles(Integer awayTeamStatisticstackles) {
        this.awayTeamStatisticstackles = awayTeamStatisticstackles;
    }

    public Integer getAwayTeamStatisticsclearances() {
        return awayTeamStatisticsclearances;
    }

    public void setAwayTeamStatisticsclearances(Integer awayTeamStatisticsclearances) {
        this.awayTeamStatisticsclearances = awayTeamStatisticsclearances;
    }

    public Integer getAwayTeamStatisticsyellowCards() {
        return awayTeamStatisticsyellowCards;
    }

    public void setAwayTeamStatisticsyellowCards(Integer awayTeamStatisticsyellowCards) {
        this.awayTeamStatisticsyellowCards = awayTeamStatisticsyellowCards;
    }

    public Boolean getAwayTeamStatisticsredCards() {
        return awayTeamStatisticsredCards;
    }

    public void setAwayTeamStatisticsredCards(Boolean awayTeamStatisticsredCards) {
        this.awayTeamStatisticsredCards = awayTeamStatisticsredCards;
    }

    public Integer getAwayTeamStatisticsfoulsCommitted() {
        return awayTeamStatisticsfoulsCommitted;
    }

    public void setAwayTeamStatisticsfoulsCommitted(Integer awayTeamStatisticsfoulsCommitted) {
        this.awayTeamStatisticsfoulsCommitted = awayTeamStatisticsfoulsCommitted;
    }

    public String getAwayTeamStatisticscountry() {
        return awayTeamStatisticscountry;
    }

    public void setAwayTeamStatisticscountry(String awayTeamStatisticscountry) {
        this.awayTeamStatisticscountry = awayTeamStatisticscountry;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    public String getLastEventUpdateAt() {
        return lastEventUpdateAt;
    }

    public void setLastEventUpdateAt(String lastEventUpdateAt) {
        this.lastEventUpdateAt = lastEventUpdateAt;
    }

    public String getLastScoreUpdateAt() {
        return lastScoreUpdateAt;
    }

    public void setLastScoreUpdateAt(String lastScoreUpdateAt) {
        this.lastScoreUpdateAt = lastScoreUpdateAt;
    }

    public String getHomeTeamcountry() {
        return homeTeamcountry;
    }

    public void setHomeTeamcountry(String homeTeamcountry) {
        this.homeTeamcountry = homeTeamcountry;
    }

    public String getHomeTeamcode() {
        return homeTeamcode;
    }

    public void setHomeTeamcode(String homeTeamcode) {
        this.homeTeamcode = homeTeamcode;
    }

    public Integer getHomeTeamgoals() {
        return homeTeamgoals;
    }

    public void setHomeTeamgoals(Integer homeTeamgoals) {
        this.homeTeamgoals = homeTeamgoals;
    }

    public String getAwayTeamcountry() {
        return awayTeamcountry;
    }

    public void setAwayTeamcountry(String awayTeamcountry) {
        this.awayTeamcountry = awayTeamcountry;
    }

    public String getAwayTeamcode() {
        return awayTeamcode;
    }

    public void setAwayTeamcode(String awayTeamcode) {
        this.awayTeamcode = awayTeamcode;
    }

    public Integer getAwayTeamgoals() {
        return awayTeamgoals;
    }

    public void setAwayTeamgoals(Integer awayTeamgoals) {
        this.awayTeamgoals = awayTeamgoals;
    }

    public String getWinner() {
        return winner;
    }

    public void setWinner(String winner) {
        this.winner = winner;
    }

    public String getWinnerCode() {
        return winnerCode;
    }

    public void setWinnerCode(String winnerCode) {
        this.winnerCode = winnerCode;
    }

    public Integer getHomeTeamEvents0id() {
        return homeTeamEvents0id;
    }

    public void setHomeTeamEvents0id(Integer homeTeamEvents0id) {
        this.homeTeamEvents0id = homeTeamEvents0id;
    }

    public String getHomeTeamEvents0typeOfEvent() {
        return homeTeamEvents0typeOfEvent;
    }

    public void setHomeTeamEvents0typeOfEvent(String homeTeamEvents0typeOfEvent) {
        this.homeTeamEvents0typeOfEvent = homeTeamEvents0typeOfEvent;
    }

    public String getHomeTeamEvents0player() {
        return homeTeamEvents0player;
    }

    public void setHomeTeamEvents0player(String homeTeamEvents0player) {
        this.homeTeamEvents0player = homeTeamEvents0player;
    }

    public String getHomeTeamEvents0time() {
        return homeTeamEvents0time;
    }

    public void setHomeTeamEvents0time(String homeTeamEvents0time) {
        this.homeTeamEvents0time = homeTeamEvents0time;
    }

    public Integer getHomeTeamEvents1id() {
        return homeTeamEvents1id;
    }

    public void setHomeTeamEvents1id(Integer homeTeamEvents1id) {
        this.homeTeamEvents1id = homeTeamEvents1id;
    }

    public String getHomeTeamEvents1typeOfEvent() {
        return homeTeamEvents1typeOfEvent;
    }

    public void setHomeTeamEvents1typeOfEvent(String homeTeamEvents1typeOfEvent) {
        this.homeTeamEvents1typeOfEvent = homeTeamEvents1typeOfEvent;
    }

    public String getHomeTeamEvents1player() {
        return homeTeamEvents1player;
    }

    public void setHomeTeamEvents1player(String homeTeamEvents1player) {
        this.homeTeamEvents1player = homeTeamEvents1player;
    }

    public String getHomeTeamEvents1time() {
        return homeTeamEvents1time;
    }

    public void setHomeTeamEvents1time(String homeTeamEvents1time) {
        this.homeTeamEvents1time = homeTeamEvents1time;
    }

    public Integer getHomeTeamEvents2id() {
        return homeTeamEvents2id;
    }

    public void setHomeTeamEvents2id(Integer homeTeamEvents2id) {
        this.homeTeamEvents2id = homeTeamEvents2id;
    }

    public String getHomeTeamEvents2typeOfEvent() {
        return homeTeamEvents2typeOfEvent;
    }

    public void setHomeTeamEvents2typeOfEvent(String homeTeamEvents2typeOfEvent) {
        this.homeTeamEvents2typeOfEvent = homeTeamEvents2typeOfEvent;
    }

    public String getHomeTeamEvents2player() {
        return homeTeamEvents2player;
    }

    public void setHomeTeamEvents2player(String homeTeamEvents2player) {
        this.homeTeamEvents2player = homeTeamEvents2player;
    }

    public String getHomeTeamEvents2time() {
        return homeTeamEvents2time;
    }

    public void setHomeTeamEvents2time(String homeTeamEvents2time) {
        this.homeTeamEvents2time = homeTeamEvents2time;
    }

    public Integer getHomeTeamEvents3id() {
        return homeTeamEvents3id;
    }

    public void setHomeTeamEvents3id(Integer homeTeamEvents3id) {
        this.homeTeamEvents3id = homeTeamEvents3id;
    }

    public String getHomeTeamEvents3typeOfEvent() {
        return homeTeamEvents3typeOfEvent;
    }

    public void setHomeTeamEvents3typeOfEvent(String homeTeamEvents3typeOfEvent) {
        this.homeTeamEvents3typeOfEvent = homeTeamEvents3typeOfEvent;
    }

    public String getHomeTeamEvents3player() {
        return homeTeamEvents3player;
    }

    public void setHomeTeamEvents3player(String homeTeamEvents3player) {
        this.homeTeamEvents3player = homeTeamEvents3player;
    }

    public Date getHomeTeamEvents3time() {
        return homeTeamEvents3time;
    }

    public void setHomeTeamEvents3time(Date homeTeamEvents3time) {
        this.homeTeamEvents3time = homeTeamEvents3time;
    }

    public Integer getHomeTeamEvents4id() {
        return homeTeamEvents4id;
    }

    public void setHomeTeamEvents4id(Integer homeTeamEvents4id) {
        this.homeTeamEvents4id = homeTeamEvents4id;
    }

    public String getHomeTeamEvents4typeOfEvent() {
        return homeTeamEvents4typeOfEvent;
    }

    public void setHomeTeamEvents4typeOfEvent(String homeTeamEvents4typeOfEvent) {
        this.homeTeamEvents4typeOfEvent = homeTeamEvents4typeOfEvent;
    }

    public String getHomeTeamEvents4player() {
        return homeTeamEvents4player;
    }

    public void setHomeTeamEvents4player(String homeTeamEvents4player) {
        this.homeTeamEvents4player = homeTeamEvents4player;
    }

    public Date getHomeTeamEvents4time() {
        return homeTeamEvents4time;
    }

    public void setHomeTeamEvents4time(Date homeTeamEvents4time) {
        this.homeTeamEvents4time = homeTeamEvents4time;
    }

    public Integer getHomeTeamEvents5id() {
        return homeTeamEvents5id;
    }

    public void setHomeTeamEvents5id(Integer homeTeamEvents5id) {
        this.homeTeamEvents5id = homeTeamEvents5id;
    }

    public String getHomeTeamEvents5typeOfEvent() {
        return homeTeamEvents5typeOfEvent;
    }

    public void setHomeTeamEvents5typeOfEvent(String homeTeamEvents5typeOfEvent) {
        this.homeTeamEvents5typeOfEvent = homeTeamEvents5typeOfEvent;
    }

    public String getHomeTeamEvents5player() {
        return homeTeamEvents5player;
    }

    public void setHomeTeamEvents5player(String homeTeamEvents5player) {
        this.homeTeamEvents5player = homeTeamEvents5player;
    }

    public Date getHomeTeamEvents5time() {
        return homeTeamEvents5time;
    }

    public void setHomeTeamEvents5time(Date homeTeamEvents5time) {
        this.homeTeamEvents5time = homeTeamEvents5time;
    }

    public Integer getHomeTeamEvents6id() {
        return homeTeamEvents6id;
    }

    public void setHomeTeamEvents6id(Integer homeTeamEvents6id) {
        this.homeTeamEvents6id = homeTeamEvents6id;
    }

    public String getHomeTeamEvents6typeOfEvent() {
        return homeTeamEvents6typeOfEvent;
    }

    public void setHomeTeamEvents6typeOfEvent(String homeTeamEvents6typeOfEvent) {
        this.homeTeamEvents6typeOfEvent = homeTeamEvents6typeOfEvent;
    }

    public String getHomeTeamEvents6player() {
        return homeTeamEvents6player;
    }

    public void setHomeTeamEvents6player(String homeTeamEvents6player) {
        this.homeTeamEvents6player = homeTeamEvents6player;
    }

    public String getHomeTeamEvents6time() {
        return homeTeamEvents6time;
    }

    public void setHomeTeamEvents6time(String homeTeamEvents6time) {
        this.homeTeamEvents6time = homeTeamEvents6time;
    }

    public Integer getHomeTeamEvents7id() {
        return homeTeamEvents7id;
    }

    public void setHomeTeamEvents7id(Integer homeTeamEvents7id) {
        this.homeTeamEvents7id = homeTeamEvents7id;
    }

    public String getHomeTeamEvents7typeOfEvent() {
        return homeTeamEvents7typeOfEvent;
    }

    public void setHomeTeamEvents7typeOfEvent(String homeTeamEvents7typeOfEvent) {
        this.homeTeamEvents7typeOfEvent = homeTeamEvents7typeOfEvent;
    }

    public String getHomeTeamEvents7player() {
        return homeTeamEvents7player;
    }

    public void setHomeTeamEvents7player(String homeTeamEvents7player) {
        this.homeTeamEvents7player = homeTeamEvents7player;
    }

    public String getHomeTeamEvents7time() {
        return homeTeamEvents7time;
    }

    public void setHomeTeamEvents7time(String homeTeamEvents7time) {
        this.homeTeamEvents7time = homeTeamEvents7time;
    }

    public Integer getHomeTeamEvents8id() {
        return homeTeamEvents8id;
    }

    public void setHomeTeamEvents8id(Integer homeTeamEvents8id) {
        this.homeTeamEvents8id = homeTeamEvents8id;
    }

    public String getHomeTeamEvents8typeOfEvent() {
        return homeTeamEvents8typeOfEvent;
    }

    public void setHomeTeamEvents8typeOfEvent(String homeTeamEvents8typeOfEvent) {
        this.homeTeamEvents8typeOfEvent = homeTeamEvents8typeOfEvent;
    }

    public String getHomeTeamEvents8player() {
        return homeTeamEvents8player;
    }

    public void setHomeTeamEvents8player(String homeTeamEvents8player) {
        this.homeTeamEvents8player = homeTeamEvents8player;
    }

    public String getHomeTeamEvents8time() {
        return homeTeamEvents8time;
    }

    public void setHomeTeamEvents8time(String homeTeamEvents8time) {
        this.homeTeamEvents8time = homeTeamEvents8time;
    }

    public Integer getHomeTeamEvents9id() {
        return homeTeamEvents9id;
    }

    public void setHomeTeamEvents9id(Integer homeTeamEvents9id) {
        this.homeTeamEvents9id = homeTeamEvents9id;
    }

    public String getHomeTeamEvents9typeOfEvent() {
        return homeTeamEvents9typeOfEvent;
    }

    public void setHomeTeamEvents9typeOfEvent(String homeTeamEvents9typeOfEvent) {
        this.homeTeamEvents9typeOfEvent = homeTeamEvents9typeOfEvent;
    }

    public String getHomeTeamEvents9player() {
        return homeTeamEvents9player;
    }

    public void setHomeTeamEvents9player(String homeTeamEvents9player) {
        this.homeTeamEvents9player = homeTeamEvents9player;
    }

    public Date getHomeTeamEvents9time() {
        return homeTeamEvents9time;
    }

    public void setHomeTeamEvents9time(Date homeTeamEvents9time) {
        this.homeTeamEvents9time = homeTeamEvents9time;
    }

    public Integer getHomeTeamEvents10id() {
        return homeTeamEvents10id;
    }

    public void setHomeTeamEvents10id(Integer homeTeamEvents10id) {
        this.homeTeamEvents10id = homeTeamEvents10id;
    }

    public String getHomeTeamEvents10typeOfEvent() {
        return homeTeamEvents10typeOfEvent;
    }

    public void setHomeTeamEvents10typeOfEvent(String homeTeamEvents10typeOfEvent) {
        this.homeTeamEvents10typeOfEvent = homeTeamEvents10typeOfEvent;
    }

    public String getHomeTeamEvents10player() {
        return homeTeamEvents10player;
    }

    public void setHomeTeamEvents10player(String homeTeamEvents10player) {
        this.homeTeamEvents10player = homeTeamEvents10player;
    }

    public String getHomeTeamEvents10time() {
        return homeTeamEvents10time;
    }

    public void setHomeTeamEvents10time(String homeTeamEvents10time) {
        this.homeTeamEvents10time = homeTeamEvents10time;
    }

    public Integer getHomeTeamEvents11id() {
        return homeTeamEvents11id;
    }

    public void setHomeTeamEvents11id(Integer homeTeamEvents11id) {
        this.homeTeamEvents11id = homeTeamEvents11id;
    }

    public String getHomeTeamEvents11typeOfEvent() {
        return homeTeamEvents11typeOfEvent;
    }

    public void setHomeTeamEvents11typeOfEvent(String homeTeamEvents11typeOfEvent) {
        this.homeTeamEvents11typeOfEvent = homeTeamEvents11typeOfEvent;
    }

    public String getHomeTeamEvents11player() {
        return homeTeamEvents11player;
    }

    public void setHomeTeamEvents11player(String homeTeamEvents11player) {
        this.homeTeamEvents11player = homeTeamEvents11player;
    }

    public String getHomeTeamEvents11time() {
        return homeTeamEvents11time;
    }

    public void setHomeTeamEvents11time(String homeTeamEvents11time) {
        this.homeTeamEvents11time = homeTeamEvents11time;
    }

    public Integer getAwayTeamEvents0id() {
        return awayTeamEvents0id;
    }

    public void setAwayTeamEvents0id(Integer awayTeamEvents0id) {
        this.awayTeamEvents0id = awayTeamEvents0id;
    }

    public String getAwayTeamEvents0typeOfEvent() {
        return awayTeamEvents0typeOfEvent;
    }

    public void setAwayTeamEvents0typeOfEvent(String awayTeamEvents0typeOfEvent) {
        this.awayTeamEvents0typeOfEvent = awayTeamEvents0typeOfEvent;
    }

    public String getAwayTeamEvents0player() {
        return awayTeamEvents0player;
    }

    public void setAwayTeamEvents0player(String awayTeamEvents0player) {
        this.awayTeamEvents0player = awayTeamEvents0player;
    }

    public String getAwayTeamEvents0time() {
        return awayTeamEvents0time;
    }

    public void setAwayTeamEvents0time(String awayTeamEvents0time) {
        this.awayTeamEvents0time = awayTeamEvents0time;
    }

    public Integer getAwayTeamEvents1id() {
        return awayTeamEvents1id;
    }

    public void setAwayTeamEvents1id(Integer awayTeamEvents1id) {
        this.awayTeamEvents1id = awayTeamEvents1id;
    }

    public String getAwayTeamEvents1typeOfEvent() {
        return awayTeamEvents1typeOfEvent;
    }

    public void setAwayTeamEvents1typeOfEvent(String awayTeamEvents1typeOfEvent) {
        this.awayTeamEvents1typeOfEvent = awayTeamEvents1typeOfEvent;
    }

    public String getAwayTeamEvents1player() {
        return awayTeamEvents1player;
    }

    public void setAwayTeamEvents1player(String awayTeamEvents1player) {
        this.awayTeamEvents1player = awayTeamEvents1player;
    }

    public String getAwayTeamEvents1time() {
        return awayTeamEvents1time;
    }

    public void setAwayTeamEvents1time(String awayTeamEvents1time) {
        this.awayTeamEvents1time = awayTeamEvents1time;
    }

    public Integer getAwayTeamEvents2id() {
        return awayTeamEvents2id;
    }

    public void setAwayTeamEvents2id(Integer awayTeamEvents2id) {
        this.awayTeamEvents2id = awayTeamEvents2id;
    }

    public String getAwayTeamEvents2typeOfEvent() {
        return awayTeamEvents2typeOfEvent;
    }

    public void setAwayTeamEvents2typeOfEvent(String awayTeamEvents2typeOfEvent) {
        this.awayTeamEvents2typeOfEvent = awayTeamEvents2typeOfEvent;
    }

    public String getAwayTeamEvents2player() {
        return awayTeamEvents2player;
    }

    public void setAwayTeamEvents2player(String awayTeamEvents2player) {
        this.awayTeamEvents2player = awayTeamEvents2player;
    }

    public String getAwayTeamEvents2time() {
        return awayTeamEvents2time;
    }

    public void setAwayTeamEvents2time(String awayTeamEvents2time) {
        this.awayTeamEvents2time = awayTeamEvents2time;
    }

    public Integer getAwayTeamEvents3id() {
        return awayTeamEvents3id;
    }

    public void setAwayTeamEvents3id(Integer awayTeamEvents3id) {
        this.awayTeamEvents3id = awayTeamEvents3id;
    }

    public String getAwayTeamEvents3typeOfEvent() {
        return awayTeamEvents3typeOfEvent;
    }

    public void setAwayTeamEvents3typeOfEvent(String awayTeamEvents3typeOfEvent) {
        this.awayTeamEvents3typeOfEvent = awayTeamEvents3typeOfEvent;
    }

    public String getAwayTeamEvents3player() {
        return awayTeamEvents3player;
    }

    public void setAwayTeamEvents3player(String awayTeamEvents3player) {
        this.awayTeamEvents3player = awayTeamEvents3player;
    }

    public Date getAwayTeamEvents3time() {
        return awayTeamEvents3time;
    }

    public void setAwayTeamEvents3time(Date awayTeamEvents3time) {
        this.awayTeamEvents3time = awayTeamEvents3time;
    }

    public Integer getAwayTeamEvents4id() {
        return awayTeamEvents4id;
    }

    public void setAwayTeamEvents4id(Integer awayTeamEvents4id) {
        this.awayTeamEvents4id = awayTeamEvents4id;
    }

    public String getAwayTeamEvents4typeOfEvent() {
        return awayTeamEvents4typeOfEvent;
    }

    public void setAwayTeamEvents4typeOfEvent(String awayTeamEvents4typeOfEvent) {
        this.awayTeamEvents4typeOfEvent = awayTeamEvents4typeOfEvent;
    }

    public String getAwayTeamEvents4player() {
        return awayTeamEvents4player;
    }

    public void setAwayTeamEvents4player(String awayTeamEvents4player) {
        this.awayTeamEvents4player = awayTeamEvents4player;
    }

    public Date getAwayTeamEvents4time() {
        return awayTeamEvents4time;
    }

    public void setAwayTeamEvents4time(Date awayTeamEvents4time) {
        this.awayTeamEvents4time = awayTeamEvents4time;
    }

    public Integer getAwayTeamEvents5id() {
        return awayTeamEvents5id;
    }

    public void setAwayTeamEvents5id(Integer awayTeamEvents5id) {
        this.awayTeamEvents5id = awayTeamEvents5id;
    }

    public String getAwayTeamEvents5typeOfEvent() {
        return awayTeamEvents5typeOfEvent;
    }

    public void setAwayTeamEvents5typeOfEvent(String awayTeamEvents5typeOfEvent) {
        this.awayTeamEvents5typeOfEvent = awayTeamEvents5typeOfEvent;
    }

    public String getAwayTeamEvents5player() {
        return awayTeamEvents5player;
    }

    public void setAwayTeamEvents5player(String awayTeamEvents5player) {
        this.awayTeamEvents5player = awayTeamEvents5player;
    }

    public Date getAwayTeamEvents5time() {
        return awayTeamEvents5time;
    }

    public void setAwayTeamEvents5time(Date awayTeamEvents5time) {
        this.awayTeamEvents5time = awayTeamEvents5time;
    }

    public Integer getAwayTeamEvents6id() {
        return awayTeamEvents6id;
    }

    public void setAwayTeamEvents6id(Integer awayTeamEvents6id) {
        this.awayTeamEvents6id = awayTeamEvents6id;
    }

    public String getAwayTeamEvents6typeOfEvent() {
        return awayTeamEvents6typeOfEvent;
    }

    public void setAwayTeamEvents6typeOfEvent(String awayTeamEvents6typeOfEvent) {
        this.awayTeamEvents6typeOfEvent = awayTeamEvents6typeOfEvent;
    }

    public String getAwayTeamEvents6player() {
        return awayTeamEvents6player;
    }

    public void setAwayTeamEvents6player(String awayTeamEvents6player) {
        this.awayTeamEvents6player = awayTeamEvents6player;
    }

    public String getAwayTeamEvents6time() {
        return awayTeamEvents6time;
    }

    public void setAwayTeamEvents6time(String awayTeamEvents6time) {
        this.awayTeamEvents6time = awayTeamEvents6time;
    }

    public Integer getAwayTeamEvents7id() {
        return awayTeamEvents7id;
    }

    public void setAwayTeamEvents7id(Integer awayTeamEvents7id) {
        this.awayTeamEvents7id = awayTeamEvents7id;
    }

    public String getAwayTeamEvents7typeOfEvent() {
        return awayTeamEvents7typeOfEvent;
    }

    public void setAwayTeamEvents7typeOfEvent(String awayTeamEvents7typeOfEvent) {
        this.awayTeamEvents7typeOfEvent = awayTeamEvents7typeOfEvent;
    }

    public String getAwayTeamEvents7player() {
        return awayTeamEvents7player;
    }

    public void setAwayTeamEvents7player(String awayTeamEvents7player) {
        this.awayTeamEvents7player = awayTeamEvents7player;
    }

    public String getAwayTeamEvents7time() {
        return awayTeamEvents7time;
    }

    public void setAwayTeamEvents7time(String awayTeamEvents7time) {
        this.awayTeamEvents7time = awayTeamEvents7time;
    }

    public Integer getAwayTeamEvents8id() {
        return awayTeamEvents8id;
    }

    public void setAwayTeamEvents8id(Integer awayTeamEvents8id) {
        this.awayTeamEvents8id = awayTeamEvents8id;
    }

    public String getAwayTeamEvents8typeOfEvent() {
        return awayTeamEvents8typeOfEvent;
    }

    public void setAwayTeamEvents8typeOfEvent(String awayTeamEvents8typeOfEvent) {
        this.awayTeamEvents8typeOfEvent = awayTeamEvents8typeOfEvent;
    }

    public String getAwayTeamEvents8player() {
        return awayTeamEvents8player;
    }

    public void setAwayTeamEvents8player(String awayTeamEvents8player) {
        this.awayTeamEvents8player = awayTeamEvents8player;
    }

    public String getAwayTeamEvents8time() {
        return awayTeamEvents8time;
    }

    public void setAwayTeamEvents8time(String awayTeamEvents8time) {
        this.awayTeamEvents8time = awayTeamEvents8time;
    }

    public Integer getAwayTeamEvents9id() {
        return awayTeamEvents9id;
    }

    public void setAwayTeamEvents9id(Integer awayTeamEvents9id) {
        this.awayTeamEvents9id = awayTeamEvents9id;
    }

    public String getAwayTeamEvents9typeOfEvent() {
        return awayTeamEvents9typeOfEvent;
    }

    public void setAwayTeamEvents9typeOfEvent(String awayTeamEvents9typeOfEvent) {
        this.awayTeamEvents9typeOfEvent = awayTeamEvents9typeOfEvent;
    }

    public String getAwayTeamEvents9player() {
        return awayTeamEvents9player;
    }

    public void setAwayTeamEvents9player(String awayTeamEvents9player) {
        this.awayTeamEvents9player = awayTeamEvents9player;
    }

    public Date getAwayTeamEvents9time() {
        return awayTeamEvents9time;
    }

    public void setAwayTeamEvents9time(Date awayTeamEvents9time) {
        this.awayTeamEvents9time = awayTeamEvents9time;
    }

    public Integer getAwayTeamEvents10id() {
        return awayTeamEvents10id;
    }

    public void setAwayTeamEvents10id(Integer awayTeamEvents10id) {
        this.awayTeamEvents10id = awayTeamEvents10id;
    }

    public String getAwayTeamEvents10typeOfEvent() {
        return awayTeamEvents10typeOfEvent;
    }

    public void setAwayTeamEvents10typeOfEvent(String awayTeamEvents10typeOfEvent) {
        this.awayTeamEvents10typeOfEvent = awayTeamEvents10typeOfEvent;
    }

    public String getAwayTeamEvents10player() {
        return awayTeamEvents10player;
    }

    public void setAwayTeamEvents10player(String awayTeamEvents10player) {
        this.awayTeamEvents10player = awayTeamEvents10player;
    }

    public String getAwayTeamEvents10time() {
        return awayTeamEvents10time;
    }

    public void setAwayTeamEvents10time(String awayTeamEvents10time) {
        this.awayTeamEvents10time = awayTeamEvents10time;
    }

    public String getHomeTeamStatistics() {
        return homeTeamStatistics;
    }

    public void setHomeTeamStatistics(String homeTeamStatistics) {
        this.homeTeamStatistics = homeTeamStatistics;
    }

    public String getAwayTeamStatistics() {
        return awayTeamStatistics;
    }

    public void setAwayTeamStatistics(String awayTeamStatistics) {
        this.awayTeamStatistics = awayTeamStatistics;
    }

    public String getHomeTeamteamTbd() {
        return homeTeamteamTbd;
    }

    public void setHomeTeamteamTbd(String homeTeamteamTbd) {
        this.homeTeamteamTbd = homeTeamteamTbd;
    }

    public String getAwayTeamteamTbd() {
        return awayTeamteamTbd;
    }

    public void setAwayTeamteamTbd(String awayTeamteamTbd) {
        this.awayTeamteamTbd = awayTeamteamTbd;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (venue != null ? venue.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Matches)) {
            return false;
        }
        Matches other = (Matches) object;
        if ((this.venue == null && other.venue != null) || (this.venue != null && !this.venue.equals(other.venue))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Matches[ venue=" + venue + " ]";
    }
    
}
