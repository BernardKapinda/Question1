/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Bernard Kapinda
 */
@Entity
@Table(name = "match_results")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MatchResults.findAll", query = "SELECT m FROM MatchResults m")
    , @NamedQuery(name = "MatchResults.findById", query = "SELECT m FROM MatchResults m WHERE m.id = :id")
    , @NamedQuery(name = "MatchResults.findByCountry", query = "SELECT m FROM MatchResults m WHERE m.country = :country")
    , @NamedQuery(name = "MatchResults.findByAlternateName", query = "SELECT m FROM MatchResults m WHERE m.alternateName = :alternateName")
    , @NamedQuery(name = "MatchResults.findByFifaCode", query = "SELECT m FROM MatchResults m WHERE m.fifaCode = :fifaCode")
    , @NamedQuery(name = "MatchResults.findByGroupId", query = "SELECT m FROM MatchResults m WHERE m.groupId = :groupId")
    , @NamedQuery(name = "MatchResults.findByGroupLetter", query = "SELECT m FROM MatchResults m WHERE m.groupLetter = :groupLetter")
    , @NamedQuery(name = "MatchResults.findByWins", query = "SELECT m FROM MatchResults m WHERE m.wins = :wins")
    , @NamedQuery(name = "MatchResults.findByDraws", query = "SELECT m FROM MatchResults m WHERE m.draws = :draws")
    , @NamedQuery(name = "MatchResults.findByLosses", query = "SELECT m FROM MatchResults m WHERE m.losses = :losses")
    , @NamedQuery(name = "MatchResults.findByGamesPlayed", query = "SELECT m FROM MatchResults m WHERE m.gamesPlayed = :gamesPlayed")
    , @NamedQuery(name = "MatchResults.findByPoints", query = "SELECT m FROM MatchResults m WHERE m.points = :points")
    , @NamedQuery(name = "MatchResults.findByGoalsFor", query = "SELECT m FROM MatchResults m WHERE m.goalsFor = :goalsFor")
    , @NamedQuery(name = "MatchResults.findByGoalsAgainst", query = "SELECT m FROM MatchResults m WHERE m.goalsAgainst = :goalsAgainst")
    , @NamedQuery(name = "MatchResults.findByGoalDifferential", query = "SELECT m FROM MatchResults m WHERE m.goalDifferential = :goalDifferential")})
public class MatchResults implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "country")
    private String country;
    @Column(name = "alternate_name")
    private String alternateName;
    @Basic(optional = false)
    @Column(name = "fifa_code")
    private String fifaCode;
    @Basic(optional = false)
    @Column(name = "group_id")
    private int groupId;
    @Basic(optional = false)
    @Column(name = "group_letter")
    private String groupLetter;
    @Basic(optional = false)
    @Column(name = "wins")
    private int wins;
    @Basic(optional = false)
    @Column(name = "draws")
    private boolean draws;
    @Basic(optional = false)
    @Column(name = "losses")
    private int losses;
    @Basic(optional = false)
    @Column(name = "games_played")
    private int gamesPlayed;
    @Basic(optional = false)
    @Column(name = "points")
    private int points;
    @Basic(optional = false)
    @Column(name = "goals_for")
    private int goalsFor;
    @Basic(optional = false)
    @Column(name = "goals_against")
    private int goalsAgainst;
    @Basic(optional = false)
    @Column(name = "goal_differential")
    private int goalDifferential;

    public MatchResults() {
    }

    public MatchResults(Integer id) {
        this.id = id;
    }

    public MatchResults(Integer id, String country, String fifaCode, int groupId, String groupLetter, int wins, boolean draws, int losses, int gamesPlayed, int points, int goalsFor, int goalsAgainst, int goalDifferential) {
        this.id = id;
        this.country = country;
        this.fifaCode = fifaCode;
        this.groupId = groupId;
        this.groupLetter = groupLetter;
        this.wins = wins;
        this.draws = draws;
        this.losses = losses;
        this.gamesPlayed = gamesPlayed;
        this.points = points;
        this.goalsFor = goalsFor;
        this.goalsAgainst = goalsAgainst;
        this.goalDifferential = goalDifferential;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getAlternateName() {
        return alternateName;
    }

    public void setAlternateName(String alternateName) {
        this.alternateName = alternateName;
    }

    public String getFifaCode() {
        return fifaCode;
    }

    public void setFifaCode(String fifaCode) {
        this.fifaCode = fifaCode;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getGroupLetter() {
        return groupLetter;
    }

    public void setGroupLetter(String groupLetter) {
        this.groupLetter = groupLetter;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public boolean getDraws() {
        return draws;
    }

    public void setDraws(boolean draws) {
        this.draws = draws;
    }

    public int getLosses() {
        return losses;
    }

    public void setLosses(int losses) {
        this.losses = losses;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getGoalsFor() {
        return goalsFor;
    }

    public void setGoalsFor(int goalsFor) {
        this.goalsFor = goalsFor;
    }

    public int getGoalsAgainst() {
        return goalsAgainst;
    }

    public void setGoalsAgainst(int goalsAgainst) {
        this.goalsAgainst = goalsAgainst;
    }

    public int getGoalDifferential() {
        return goalDifferential;
    }

    public void setGoalDifferential(int goalDifferential) {
        this.goalDifferential = goalDifferential;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MatchResults)) {
            return false;
        }
        MatchResults other = (MatchResults) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.MatchResults[ id=" + id + " ]";
    }
    
}
